create trigger AllStarFullFixed
  before INSERT
  on AllStarFullFixed
  for each row
  BEGIN
  IF NOT (NEW.startingPos>='1' AND NEW.startingPos<='10') THEN
      SIGNAL SQLSTATE '45001'
      SET MESSAGE_TEXT = 'startPOS is invalid.';
  END IF;
  IF NOT (NEW.yearID>='1933' AND NEW.yearID<='2018') THEN
      SIGNAL SQLSTATE '45001'
      SET MESSAGE_TEXT = 'yearID is invalid.';
  END IF;
END;


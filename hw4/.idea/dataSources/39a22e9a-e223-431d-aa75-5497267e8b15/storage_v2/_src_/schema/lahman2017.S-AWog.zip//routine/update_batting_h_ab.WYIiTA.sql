create procedure update_batting_h_ab(IN playerID_u varchar(32), IN teamID_u varchar(32), IN yearID_u varchar(32),
                                     IN stint_u    varchar(32), IN hits_u int, IN abs_u int)
  BEGIN
  DECLARE total_hits_u INT UNSIGNED DEFAULT 0;
  DECLARE total_abs_u INT UNSIGNED DEFAULT 0;
  DECLARE average_u INT UNSIGNED DEFAULT 0;
  UPDATE Batting b SET H=hits_u, AB=abs_u WHERE playerID=playerID_u AND teamID=teamID_u and yearID=yearID_u and stint=stint_u;
  SELECT sum(h) ,sum(ab), IF(sum(ab)=0, NULL, round(sum(h)/sum(ab), 3)) INTO total_hits_u,total_abs_u,average_u FROM Batting WHERE playerID=playerID_u and teamID=teamID_u and yearID=yearID_u GROUP BY playerID,yearID,teamID;
  UPDATE copy_tables_are_awesome SET total_hits=total_hits_u, total_abs=total_abs_u, average = average_u WHERE playerid=playerID_u and yearid=yearID_u and teamid=teamID_u;
END;


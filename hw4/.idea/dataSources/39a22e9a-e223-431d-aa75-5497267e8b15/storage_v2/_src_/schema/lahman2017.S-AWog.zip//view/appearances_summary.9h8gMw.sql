create view appearances_summary as
  select `lahman2017`.`appearances`.`playerID`  AS `playerID`,
         `lahman2017`.`appearances`.`teamID`    AS `teamID`,
         `lahman2017`.`appearances`.`yearID`    AS `yearID`,
         `lahman2017`.`appearances`.`G_all`     AS `g_all`,
         `lahman2017`.`appearances`.`G_batting` AS `g_batting`,
         `lahman2017`.`appearances`.`G_defense` AS `g_defense`,
         `lahman2017`.`appearances`.`G_p`       AS `g_pitching`
  from `lahman2017`.`appearances`;


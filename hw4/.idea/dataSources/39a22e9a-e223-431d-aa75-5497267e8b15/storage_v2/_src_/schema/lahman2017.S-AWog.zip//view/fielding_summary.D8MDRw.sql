create view fielding_summary as
  select `lahman2017`.`fielding`.`playerID` AS `playerID`,
         `lahman2017`.`fielding`.`teamID`   AS `teamID`,
         `lahman2017`.`fielding`.`yearID`   AS `yearID`,
         `lahman2017`.`fielding`.`PO`       AS `put_outs`,
         `lahman2017`.`fielding`.`A`        AS `assists`,
         `lahman2017`.`fielding`.`E`        AS `errors`
  from `lahman2017`.`fielding`;


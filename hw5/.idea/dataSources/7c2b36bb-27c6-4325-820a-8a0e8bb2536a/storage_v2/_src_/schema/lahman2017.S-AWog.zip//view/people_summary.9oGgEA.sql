create view people_summary as
  select `lahman2017`.`people`.`playerID`  AS `playerID`,
         `lahman2017`.`people`.`nameLast`  AS `nameLast`,
         `lahman2017`.`people`.`nameFirst` AS `nameFirst`,
         `lahman2017`.`people`.`bats`      AS `bats`,
         `lahman2017`.`people`.`throws`    AS `throws`
  from `lahman2017`.`people`;


create view batting_summary as
  select `lahman2017`.`batting`.`playerID` AS `playerID`,
         `lahman2017`.`batting`.`teamID`   AS `teamID`,
         `lahman2017`.`batting`.`yearID`   AS `yearID`,
         `lahman2017`.`batting`.`H`        AS `hits`,
         `lahman2017`.`batting`.`AB`       AS `at_bats`,
         `lahman2017`.`batting`.`HR`       AS `hrs`,
         `lahman2017`.`batting`.`RBI`      AS `RBIs`
  from `lahman2017`.`batting`;


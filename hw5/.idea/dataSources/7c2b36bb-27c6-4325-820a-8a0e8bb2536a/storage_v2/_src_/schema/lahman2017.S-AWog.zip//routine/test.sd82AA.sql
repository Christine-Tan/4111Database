create procedure test()
  begin
declare v_1 INT;
declare v_2 INT;
end;


create view pitching_summary as
  select `lahman2017`.`pitching`.`playerID` AS `playerID`,
         `lahman2017`.`pitching`.`teamID`   AS `teamID`,
         `lahman2017`.`pitching`.`yearID`   AS `yearID`,
         `lahman2017`.`pitching`.`W`        AS `wins`,
         `lahman2017`.`pitching`.`L`        AS `loses`,
         `lahman2017`.`pitching`.`G`        AS `games`,
         `lahman2017`.`pitching`.`IPouts`   AS `outs_pitched`
  from `lahman2017`.`pitching`;

